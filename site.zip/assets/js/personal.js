(() => {
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('.site-menu');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    menu.classList.toggle('is-open', open);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') {
      toggle.setAttribute('aria-expanded', 'false'); menu.classList.remove('is-open'); toggle.focus();
    }
  });
  document.querySelector('.language-switch')?.addEventListener('click', (event) => {
    const link = event.currentTarget;
    if (location.hash) link.hash = location.hash;
  });
  const search = document.querySelector('#publication-search');
  const filters = document.querySelectorAll('[data-filter]');
  let active = 'all';
  function filterPapers() {
    const query = (search?.value || '').trim().toLowerCase();
    let visible = 0;
    document.querySelectorAll('.publication[data-type]').forEach(paper => {
      const show = (active === 'all' || paper.dataset.type === active) && paper.textContent.toLowerCase().includes(query);
      paper.hidden = !show; if (show) visible++;
    });
    document.querySelectorAll('.publication-year-group').forEach(group => {
      group.hidden = ![...group.querySelectorAll('.publication')].some(p => !p.hidden);
    });
    const empty = document.querySelector('#no-results'); if (empty) empty.hidden = visible > 0;
    const count = document.querySelector('#result-count');
    if (count) count.textContent = document.documentElement.lang === 'zh-CN' ? `${visible} 项成果` : `${visible} ${visible === 1 ? 'result' : 'results'}`;
  }
  filters.forEach(button => button.addEventListener('click', () => {
    active = button.dataset.filter;
    filters.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
    filterPapers();
  }));
  search?.addEventListener('input', filterPapers);
})();
