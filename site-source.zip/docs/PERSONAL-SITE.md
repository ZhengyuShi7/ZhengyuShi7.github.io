# 施正昱个人学术主页

本项目从 al-folio 官方 starter 建立，生产配置使用 `al_folio_core` 1.0.15 和个人专用 Liquid 布局。英文 `/en/` 与中文 `/zh/` 各含六个对应页面。DOI 可后续补充；没有链接的条目不显示空按钮。

## 查看这一版

双击上级文件夹的 `打开学术主页.html`，可直接浏览离线版本。无需安装 Ruby 或启动服务器。离线页面由 `_preview/` 打包到 `_offline/`，全部内部链接已改为文件相对路径。

本地浏览预览使用已下载的 al-folio-core 1.0.16 的预编译 `tailwind.css`；个人样式不依赖两版本间的新功能。生产版本的视觉一致性应在首次 Jekyll 构建后复核。

## 内容维护

- 学术动态：`website/_data/news.json`。首页显示最新五条，“News / 动态”页面按年份展示全部记录。
- Excel 的 News 工作表更新后运行 `python tools/import_news.py`，然后执行内容生成、预览和离线打包。英文译文在导入脚本中按源行维护；增删或重排 Excel 行后需同步映射，不能盲目直接导入。
- 根据用户 2026-11-17 的明确确认，News 第12行 UCSD 访学日期显示为 2026-02-26，原 Excel 未被改写。

- 唯一内容数据：`website/_data/profile.json`，每个双语字段包含 `en` 和 `zh`。
- 修改数据后执行 `python tools/build_content.py`，生成两种语言的页面。
- 论文 `doi` 仅填写 DOI 标识；`url` 填论文或预印本完整地址；`selected` 控制首页代表论文。
- `tools/prepare_content.py` 是首次导入原 Excel 的脚本，**日常更新不要重新运行**，以免覆盖后续补充。
- 本地预览 `_preview/` 为同一套页面和 Liquid 布局的静态渲染；生产构建使用 Jekyll。

## GitHub Pages

当前尚未发布，未配置 GitHub 账号或域名。

1. 把此项目放入自己的 GitHub 仓库。不要上传上级文件夹中的原始 Excel、原始照片或 `.site-tools`。
2. 使用用户主页仓库 `用户名.github.io` 时，`_config.personal.yml` 的 `baseurl` 保持空字符串；项目仓库则改为 `/仓库名`。
3. 把 `url` 改为最终网站域名，例如 `https://用户名.github.io`。
4. GitHub 仓库 Settings → Pages → Source 选择 GitHub Actions。
5. 运行 `Deploy personal academic site` 工作流。它使用 `Gemfile.site`，并通过 `_config.personal.yml` 只构建 `website/`，不会发布模板演示数据。

本地生产构建命令（需要 Ruby 和本机编译依赖）：

```sh
BUNDLE_GEMFILE=Gemfile.site bundle install
BUNDLE_GEMFILE=Gemfile.site bundle exec jekyll build --config _config.personal.yml
```

## 设计与语言

- 双语导航、对应页切换、手机菜单、论文关键词搜索和类型筛选。
- 图片仅供个人主页使用，原始文件未修改；网页使用等比例缩小的 JPEG 副本，通过 CSS 控制显示区域。
- 保留论文原始英文标题，中文页面翻译说明和分类。
- 保留作者列表顺序；2019 年含两个 `Shi, Z.`，在确认本人位置前不加粗。
- 2027 年洪灾论文保留用户提供年份，不额外宣称已发表或已接收。
- JASA 暂展示卷期，未显示有疑问的重复页码。
- UNEP 部署描述为推进中。未使用“首个”“第一”等尚待来源核实的宣传表述。
- 英文地址使用楼号和街道地址，暂不自行翻译校园冠名。机构、项目、职称等英文表述可后续按官方名称校订。

## 本地布局

`website/_layouts/personal.liquid` 是本站新增布局，不覆盖 al-folio 的同名布局；`personal.css` 与 `personal.js` 为本站新增文件。核心样式由 al-folio 提供。模板演示文件保留在仓库中，但不参与个人站点构建。

原模板的 GitHub 工作流已移至 `docs/template-workflows/` 留档，仅个人站点部署工作流保持启用，避免误发布演示页面。

## 已完成的验证与限制

- Liquid 本地静态渲染通过，中英文各六个页面。
- 在线预览及离线版本共 388 个站内链接、锚点和资源引用检查通过。
- 浏览器测试：语言对应页切换、会议筛选、关键词筛选、手机导航菜单。
- 12 个页面在 390px 视口下均无横向溢出；桌面首页、论文页、研究页及中文手机首页已视觉检查。
- 浏览器未记录脚本错误。
- Windows Jekyll 安装因缺少 MSYS2 编译依赖而未完成，RubyInstaller 指向的 MSYS2 下载地址返回 404。因此没有宣称完整 Jekyll 构建或 GitHub Actions 已通过。正式部署前需要执行生产构建并复核。

News 文案润色及配图维护在 website/_data/news_editorial.json，按 news-ID 覆盖导入内容。重新导入 Excel 会保留这些编辑；调整 Excel 行序时需同步 ID 映射。照片在 website/assets/img/news/，完整比例显示，点击可查看原图。

Excel 以外补充的动态维护在 website/_data/news_additions.json，导入时与 Excel 条目合并并按日期排序。
