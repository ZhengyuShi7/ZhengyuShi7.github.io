# GitHub Pages publication

Public site: https://zhengyushi7.github.io/
Repository: https://github.com/ZhengyuShi7/ZhengyuShi7.github.io

The initial publication uses the verified Liquid-rendered static site in `site.zip`. GitHub Actions `.github/workflows/deploy.yml` unpacks it and deploys its contents. The repository also contains `site-source.zip`, an archive of the editable bilingual Jekyll site and generation tools. Original Excel files and local QA artifacts are not uploaded.

To update: edit website data/assets, run tools/build_content.py, tools/preview.rb and tools/check_site.py, then tools/package_release.py. Upload release/site.zip and release/site-source.zip to the repository root, replacing their previous versions. A commit changing site.zip automatically deploys. GitHub Pages must use Source: GitHub Actions.

The repository currently deploys the static archive; editing only site-source.zip does not update the live site. Local content remains under website/. Full Jekyll builds can later replace this archive deployment without changing the website URL.
