from pathlib import Path
import json, re
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
w = openpyxl.load_workbook(ROOT.parent / '学术信息.xlsx', data_only=True)
def bi(en, zh): return {'en': en, 'zh': zh}
data = {
 'name': bi('Zhengyu Shi', '施正昱'),
 'role': bi('Postdoctoral Researcher', '博士后研究员'),
 'affiliation': bi('Artificial Intelligence Innovation and Incubation Institute, Fudan University', '复旦大学人工智能创新与产业研究院'),
 'intro': bi('I am a postdoctoral researcher at Fudan University, working with Prof. Yuan Qi. My research brings together <strong>energy governance, agent-based modeling, and statistical machine learning</strong>.', '我是复旦大学人工智能创新与产业研究院博士后，合作导师为漆远教授。我的研究围绕<strong>能源治理、智能体建模与统计机器学习</strong>展开。'),
 'intro2': bi('I study how people, markets, and policies shape the low-carbon transition, and develop AI methods for climate research and decision-making.', '我关注微观主体、市场机制与公共政策如何影响低碳转型，并探索人工智能在气候研究与决策中的应用。'),
 'topics': [bi('Energy governance','能源治理'),bi('Agent-based modeling','智能体建模'),bi('Statistical machine learning','统计机器学习')],
 'email': 'zhengyushi@fudan.edu.cn', 'email_secondary':'zhengyushi96@gmail.com',
 'scholar':'https://scholar.google.com/citations?user=NPj4tAwAAAAJ',
 'address':bi('Room 901, Building C<br>Fudan University<br>579 Guoquan Road, Yangpu District<br>Shanghai, China', '上海市杨浦区国权路579号<br>复旦大学袁天凡、慧敏校园<br>C幢901室'),
 'research': [
  {'id':'energy','title':bi('Energy governance & electricity markets','能源治理与电力市场'),
   'short':bi('Understanding market behavior and policy design for a resilient, low-carbon energy transition.','研究市场主体行为与政策设计，探索韧性低碳能源转型路径。'),
   'text':bi('My work examines decision-making by households, firms, and other participants in energy systems. I use agent-based models, game-theoretic approaches, and machine learning to study electricity market mechanisms, strategic behavior, and low-carbon transition policies.','我的研究关注家庭、企业等能源系统参与者的决策行为，结合智能体建模、博弈方法与机器学习，研究电力市场机制、主体策略行为与低碳转型政策。'),
   'topics':bi('Electricity markets · Policy simulation · Household energy demand','电力市场 · 政策模拟 · 家庭能源需求')},
  {'id':'climate','title':bi('AI for climate & environmental resilience','气候人工智能与环境韧性'),
   'short':bi('Developing climate AI, statistical downscaling, and tools for climate risk and policy analysis.','发展气候人工智能与统计降尺度方法，服务气候风险分析和政策决策。'),
   'text':bi('I work on climate language models and policy agents, as well as machine-learning methods for climate downscaling and risk assessment. This research connects methodological development with applications in climate policy, disaster risk, and urban resilience.','我参与气候语言模型、气候政策智能体以及气候降尺度和风险评估方法的研发，将人工智能方法与气候政策、灾害风险及城市韧性等应用场景相结合。'),
   'topics':bi('Climate foundation models · Statistical downscaling · Climate risk','气候基础模型 · 统计降尺度 · 气候风险')},
  {'id':'methods','title':bi('Agent-based modeling & statistical learning','智能体建模与统计学习'),
   'short':bi('Connecting statistical methods and computational models to complex social and environmental systems.','融合统计方法与计算模型，研究复杂社会经济与环境系统。'),
   'text':bi('My methodological interests span agent-based modeling, statistical machine learning, and multi-source data analysis. Applications include energy demand, urban activity, epidemic transmission risk, and the behavior of AI agents.','我的方法研究兴趣涵盖智能体建模、统计机器学习与多源数据分析，应用场景包括能源需求、城市活力、疫情传播风险以及人工智能体行为。'),
   'topics':bi('Agent-based simulation · Multi-source data · Statistical modeling','智能体模拟 · 多源数据 · 统计建模')}
 ],
 'climate_model':{
   'title':'Climate Foundation Model',
   'subtitle':bi('Climate language model & policy agents','气候语言模型与政策智能体'),
   'text':bi('I lead the development of a climate language model and climate policy agent system, formerly known as Planetary Intelligence@Climate. The work covers electricity market decisions, low-carbon policy assessment, and climate risk analysis.','我负责气候大语言模型及气候政策智能体系统的研发。模型原名 Planetary Intelligence@Climate，现名 Climate Foundation Model，面向电力市场决策、低碳政策评估和气候风险分析等场景。'),
   'impact':bi('The system supported the Chinese government delegation during COP29. Ongoing work includes multimodal model development and collaboration toward deployment of climate multi-agent tools on UNEP’s World Environment Situation Room platform.','相关系统曾支撑中国政府代表团在 COP29 的气候谈判工作。目前正在推进多模态模型研发，以及与联合国环境规划署合作，将气候多智能体工具部署至 World Environment Situation Room 平台。')
 },
 'appointments':[
  {'date':bi('2024–present','2024年至今'),'title':bi('Postdoctoral Researcher','博士后'),'place':bi('Artificial Intelligence Innovation and Incubation Institute, Fudan University','复旦大学人工智能创新与产业研究院'),'note':bi('Advisor: Prof. Yuan Qi','合作导师：漆远教授')},
  {'date':bi('2025–present','2025年至今'),'title':bi('Adjunct Researcher · Earth Sciences','地球科学领域兼聘研究员'),'place':bi('Shanghai Academy of AI for Science','上海科学智能研究院'),'note':bi('','')},
  {'date':bi('2025–2026','2025–2026'),'title':bi('Adjunct Mentor · AI for Energy and Climate Change','AI for 能源与气候变化标杆项目兼聘导师'),'place':bi('Shanghai Innovation Institute','国家人工智能学院上海创智学院'),'note':bi('','')}
 ],
 'education':[
  {'date':bi('2020–2024','2020–2024'),'title':bi('Ph.D. in Statistics','统计学博士'),'place':bi('School of Data Science, Fudan University','复旦大学大数据学院'),'note':bi('Advisor: Prof. Libo Wu','导师：吴力波教授')},
  {'date':bi('2018–2020','2018–2020'),'title':bi('Master’s in Applied Statistics','应用统计硕士'),'place':bi('School of Data Science, Fudan University','复旦大学大数据学院'),'note':bi('Advisor: Prof. Libo Wu','导师：吴力波教授')},
  {'date':bi('2014–2018','2014–2018'),'title':bi('Bachelor’s in Computer Science and Technology','计算机科学与技术学士'),'place':bi('Department of Computer Science, East China University of Political Science and Law','华东政法大学计算机系'),'note':bi('','')}
 ],
 'visits':[
  {'date':bi('2025–2026','2025–2026'),'title':bi('Visiting Scholar','访问学者'),'place':bi('School of Physics, University of Sydney, Australia','澳大利亚悉尼大学物理学院'),'note':bi('Host: Prof. Manfred Lenzen','合作导师：Manfred Lenzen 教授')},
  {'date':bi('2026','2026'),'title':bi('Visiting Scholar','访问学者'),'place':bi('School of Global Policy and Strategy, University of California San Diego, USA','美国加州大学圣地亚哥分校全球政策战略学院'),'note':bi('Host: Prof. Michael Davidson','合作导师：Michael Davidson 教授')}
 ],
 'talks':bi('Invited talks at the University of Pennsylvania, the University of California, the National University of Singapore, and the University of Sydney (2024–2026).','2024–2026年，受邀于美国宾夕法尼亚大学、加州大学、新加坡国立大学、澳大利亚悉尼大学等高校作特邀报告。'),
 'teaching':[
  bi('Teaching team member, <em>Agent-Based Modeling and Computational Social Science</em>, Fudan University’s 100 AI Courses initiative (2025).','复旦大学100门AI大课《智能体建模与计算社会科学》课程骨干（2025）。'),
  bi('Adjunct mentor for the AI for Energy and Climate Change flagship project, Shanghai Innovation Institute (2025–2026).','国家人工智能学院上海创智学院“AI for 能源与气候变化”标杆项目兼聘导师（2025–2026）。')
 ],
 'service':[
  bi('Contributing author, Topic 5: AI-Empowered Scientific and Technological Innovation for Climate Change, <em>Fifth National Assessment Report on Climate Change</em> (2025–2027).','《第五次气候变化国家评估报告》专题5“人工智能赋能气候变化科技创新”主要作者（2025–2027）。'),
  bi('Editorial committee member, 2026 Blue Book on AI Development in the Humanities and Social Sciences, <em>Rediscovering the Value of Deep Thinking</em>.','2026人文社会科学智能发展蓝皮书《重新发现“深度思考”的价值》编委成员。'),
  bi('Editorial committee member, 2025 Blue Book on AI Development in the Humanities and Social Sciences, <em>The Future Is Here</em>.','2025人文社会科学智能发展蓝皮书《未来已来》编委成员。'),
  bi('Founding member, AI for Sustainable Urban Systems and Climate Resilience (AISUS+), an initiative within the WMO GAW framework (2025).','WMO GAW倡议框架下“人工智能促进可持续城市系统和气候适应力”（AISUS+）发起成员（2025）。')
 ],
 'reviewing':['Energy Policy','Urban Climate','Economic Analysis and Policy','Computational Economics','Journal of Climate Change and Health'],
 'support':bi('Shanghai Super Postdoctoral Fellow Program · 2025–2026','上海市“超级博士后”人才支持计划 · 2025–2026')
}

papers=[]
for row in list(w['论文'].values)[1:]:
 if not row[0]: continue
 citation=str(row[0]).strip().replace('inMorally','in Morally').replace('～','–')
 m=re.search(r'\((20\d{2})\)\.?\s*',citation)
 authors=citation[:m.start()].strip()
 year=int(m.group(1)); rest=citation[m.end():]
 # Known exact title/venue split: preserve supplied bibliography rather than infer a DOI.
 title, venue=rest.split('. ',1)
 p={'id':f'paper-{len(papers)+1}','authors':authors,'year':year,'title':title,'venue':venue,'equal':row[1]=='共同一作','doi':'','url':'','selected':False}
 if 'https://doi.org/' in p['venue']:
  p['doi']=p['venue'].split('https://doi.org/')[1].strip().rstrip('.')
  p['venue']=p['venue'].split('https://doi.org/')[0].strip()
 p['type']='abstract' if 'EGU26' in venue else ('conference' if 'Main Conference' in venue else 'journal')
 labels=['EIAR','NeurIPS','EMNLP','BAMS','iScience','EGU','Appl. Energy','Sci. Reports','JASA','J. Environ. Manage.','Appl. Energy']
 p['label']=labels[len(papers)]
 # Omit unresolved JASA page range rather than display a suspect duplicate.
 if p['label']=='JASA': p['venue']='Journal of the American Statistical Association, 117(539).'
 p['note']=bi('','')
 if len(papers)==1: p['note']=bi('Accepted · NeurIPS 2026','已接收 · NeurIPS 2026')
 if p['type']=='abstract': p['note']=bi('EGU26 Highlight','EGU26 Highlight 亮点研究')
 p['selected']=len(papers) in (0,1,6)
 papers.append(p)
data['papers']=papers
project_en=[
 ('Young Scientists Fund (Category C), National Natural Science Foundation of China','Agent-based modeling of micro-level decision-making in electricity markets and low-carbon transition strategies'),
 ('19th Special Funding Program, China Postdoctoral Science Foundation','Collusive behavior of power generation groups in electricity markets using friend-or-foe game-based reinforcement learning'),
 ('Shanghai Talent Program','Shanghai Super Postdoctoral Fellow Program'),
 ('Shanghai Science and Technology Innovation Action Plan · Soft Science Research','Cost transmission and policy optimization in Shanghai’s competitive electricity market under carbon neutrality'),
 ('Shanghai Philosophy and Social Sciences Planning · Youth Project','Shanghai’s green energy transition in the context of carbon peaking and carbon neutrality'),
 ('Shanghai Innovation Institute · Frontier AI for Science Program','AI-driven resilient low-carbon power systems'),
 ('Shanghai Science and Technology Commission · Innovation Base','Shanghai Engineering Research Center for Artificial Intelligence in Electric Power')]
data['projects']=[]
for i,row in enumerate(list(w['项目'].values)[1:]):
 if not row[0]:continue
 data['projects'].append({'funder':bi(project_en[i][0],row[0]),'title':bi(project_en[i][1],row[1]),'role':bi('Principal investigator' if row[2]=='项目负责人' else 'Key contributor',row[2]),'period':row[3].replace('-','–'),'kind':'support' if i==2 else ('led' if i<2 else 'collaborative')})
out=ROOT/'website/_data/profile.json';out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Prepared {len(papers)} publications and {len(data["projects"])} project/support records.')
