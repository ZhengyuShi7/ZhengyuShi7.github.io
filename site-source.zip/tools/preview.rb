# Local static rendering of the site's Liquid layout. Production uses Jekyll.
require 'json'
require 'fileutils'
require 'time'
require 'liquid'
root = File.expand_path('..', __dir__)
source = File.join(root, 'website')
destination = File.join(root, '_preview')
module PersonalPreviewFilters
  def relative_url(path)
    "#{@context.registers[:baseurl]}#{path}"
  end
  def absolute_url(path)
    relative_url(path)
  end
end
Liquid::Template.register_filter(PersonalPreviewFilters)
FileUtils.mkdir_p(destination)
FileUtils.cp_r(File.join(source, 'assets'), destination)
theme_css = File.join(root, '..', '.site-tools', 'al-folio-core', 'assets', 'css', 'tailwind.css')
FileUtils.cp(theme_css, File.join(destination, 'assets', 'css', 'tailwind.css'))
layout = File.read(File.join(source, '_layouts', 'personal.liquid'), encoding: 'UTF-8')
site = {'url'=>'', 'baseurl'=>'', 'time'=>Time.now}
Dir.glob(File.join(source, '{en,zh}', '*.html')).each do |file|
  text = File.read(file, encoding: 'UTF-8')
  _, frontmatter, body = text.split(/^---\s*$\n?/, 3)
  page = JSON.parse(frontmatter)
  context = {'site'=>site, 'page'=>page}
  context['content'] = Liquid::Template.parse(body).render!(context, registers: {baseurl: ''}, strict_variables: true, strict_filters: true)
  html = Liquid::Template.parse(layout).render!(context, registers: {baseurl: ''}, strict_variables: true, strict_filters: true)
  output = File.join(destination, page['permalink'], 'index.html')
  FileUtils.mkdir_p(File.dirname(output)); File.write(output, html, encoding: 'UTF-8')
end
text = File.read(File.join(source, 'index.html'), encoding: 'UTF-8').split(/^---\s*$\n?/, 3).last
File.write(File.join(destination, 'index.html'), Liquid::Template.parse(text).render!({},registers:{baseurl:''}), encoding:'UTF-8')
puts "Preview generated at #{destination}"
