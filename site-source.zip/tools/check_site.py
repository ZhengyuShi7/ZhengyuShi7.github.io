from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import json
ROOT=Path(__file__).resolve().parents[1]
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=set()
 def handle_starttag(self, tag, attrs):
  a=dict(attrs)
  for key in ('href','src'):
   if key in a:self.links.append(a[key])
  if 'id' in a:self.ids.add(a['id'])
errors=[];checked=0
for folder in ['_preview','_offline']:
 root=ROOT/folder
 for p in root.rglob('*.html'):
  text=p.read_text(encoding='utf-8'); parser=Links();parser.feed(text)
  assert '{{' not in text and '{%' not in text, str(p)
  for value in parser.links:
   u=urlsplit(value)
   if u.scheme or u.netloc:continue
   q=(root/unquote(u.path).lstrip('/') if u.path.startswith('/') else p.parent/unquote(u.path)) if u.path else p
   if q.is_dir():q=q/'index.html'
   checked+=1
   if not q.exists():errors.append(f'{p}: {value}')
   elif u.fragment and q.suffix=='.html':
    target=Links();target.feed(q.read_text(encoding='utf-8'))
    if u.fragment not in target.ids:errors.append(f'{p}: missing anchor {value}')
for p in (ROOT/'website').glob('*/*.html'):
 meta=json.loads(p.read_text(encoding='utf-8').split('---',2)[1])
 assert meta['layout']=='personal'
 assert meta['alternate']!=meta['permalink']
d=json.loads((ROOT/'website/_data/profile.json').read_text(encoding='utf-8'))
assert len(d['papers'])==11
assert sum(p['type']=='journal' for p in d['papers'])==8
assert sum(p['type']=='conference' for p in d['papers'])==2
assert sum(p['type']=='abstract' for p in d['papers'])==1
news=json.loads((ROOT/'website/_data/news.json').read_text(encoding='utf-8'))
assert len(news)==31
assert next(n for n in news if n['id']=='news-12')['start']=='2026-02-26'
assert [n['start'] for n in news]==sorted([n['start'] for n in news],reverse=True)
print(json.dumps({'pages_per_language':len(list((ROOT/'website/en').glob('*.html'))),'checked_links_and_assets':checked,'papers':11,'news':len(news),'errors':errors},ensure_ascii=False))
assert not errors
