from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
path=root/'website/_data/profile.json'
d=json.loads(path.read_text(encoding='utf-8'))
def bi(en,zh):return {'en':en,'zh':zh}
d['research'].sort(key=lambda r:['climate','energy','methods'].index(r['id']))
d['intro']=bi('I am a postdoctoral researcher at Fudan University, working with Prof. Yuan Qi. My current research increasingly focuses on <strong>AI for climate and environmental resilience</strong>, building on my work in energy governance, agent-based modeling, and statistical machine learning.','我是复旦大学人工智能创新与产业研究院博士后，合作导师为漆远教授。基于能源治理、智能体建模与统计机器学习的研究积累，我目前正将研究重点转向<strong>气候人工智能与环境韧性</strong>。')
d['intro2']=bi('I lead the development of the <strong>Climate Foundation Model (CFM)</strong> and climate policy agents, connecting AI methods with climate research, risk assessment, and decision-making.','我负责 <strong>Climate Foundation Model（CFM）气候大模型</strong>及气候政策智能体系统研发，推动人工智能方法在气候研究、风险评估与决策中的应用。')
d['topics']=[bi('Climate AI & resilience','气候人工智能与环境韧性'),bi('Energy governance','能源治理'),bi('Agent-based modeling & statistical learning','智能体建模与统计学习')]
d['about_highlights']=[
 bi('I am a contributing author of Topic 5, “AI-Empowered Scientific and Technological Innovation for Climate Change,” in the <em>Fifth National Assessment Report on Climate Change</em> (2025–2027), and a recipient of support from the <strong>Shanghai Super Postdoctoral Fellow Program</strong> (2025–2026).','担任<strong>《第五次气候变化国家评估报告》专题5“人工智能赋能气候变化科技创新”主要作者</strong>（2025–2027），入选<strong>上海市“超级博士后”</strong>人才支持计划（2025–2026）。'),
 bi('My international research experience includes visiting appointments at the <strong>School of Physics, University of Sydney</strong> (2025–2026), working with Prof. Manfred Lenzen, and the <strong>School of Global Policy and Strategy, University of California San Diego</strong> (2026), working with Prof. Michael Davidson.','曾在<strong>澳大利亚悉尼大学物理学院</strong>访学（2025–2026），合作导师为 Manfred Lenzen 教授；在<strong>美国加州大学圣地亚哥分校全球政策战略学院</strong>访学（2026），合作导师为 Michael Davidson 教授。')]
d['applications']=bi('My research has been applied at the China Academy of Information and Communications Technology (CAICT), State Grid Shanghai, Bank of Communications in Shanghai, and China Pacific Insurance Group, among others.','相关研究成果已运用于中国信通院、国家电网上海公司、上海交通银行、中国太平洋保险集团等。')
new_projects=[
 ('Ministry of Ecology and Environment · Department of Climate Change','生态环境部应对气候变化司','Meteorological data collection and analysis, and analysis of impact risks from extreme weather and climate events','气象数据收集分析及极端天气气候事件影响风险分析','2024–2025','Key contributor','项目骨干'),
 ('Anhui Province','安徽省','Carbon-inclusive methodologies for distributed photovoltaics, electric vehicles, and residential electricity use in Anhui Province','安徽省分布式光伏、电动汽车和居民用电碳普惠方法学研究','2024–2025','Deputy head of the research team','课题组副组长'),
 ('State Grid Shanghai','国网上海','Technical services for improving urban emergency management capabilities using electricity big data','基于电力大数据的城市应急管理能力提升技术服务','2023–2024','Key contributor','项目骨干'),
 ('East China Electric Power Test and Research Institute','华东电力试验研究院','Research and planning for a data-as-a-factor standards framework for electric power enterprises','电力企业数据要素化标准体系研究与布局','2022–2023','Key contributor','项目骨干'),
 ('East China Electric Power Test and Research Institute','华东电力试验研究院','Pricing decisions and application scenarios for electric power data assets','电力数据资产定价决策与应用场景研究','2022–2023','Key contributor','项目骨干')]
for en_f,zh_f,en_t,zh_t,period,en_r,zh_r in new_projects:
 if not any(p['title']['zh']==zh_t for p in d['projects']):
  d['projects'].append({'funder':bi(en_f,zh_f),'title':bi(en_t,zh_t),'role':bi(en_r,zh_r),'period':period,'kind':'collaborative'})
d['projects'].sort(key=lambda p:int(p['period'][:4]),reverse=True)
dois={'paper-1':'10.1016/j.eiar.2026.108780','paper-5':'10.1016/j.isci.2026.116010','paper-8':'10.1038/s41598-022-24670-z','paper-7':'10.1016/j.apenergy.2023.121899','paper-4':'10.1175/BAMS-D-26-0311.1','paper-11':'10.1016/j.apenergy.2019.03.014','paper-10':'10.1016/j.jenvman.2021.113501','paper-9':'10.1080/01621459.2022.2096038'}
for p in d['papers']:
 if p['id'] in dois:p['doi']=dois[p['id']]
path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Updated research order, biography, 5 projects, applications and 8 DOI fields.')
