"""Package the verified local rendering for the GitHub Pages upload workflow."""
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
out=root/'release'
out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'site.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((root/'_preview').rglob('*')):
  if p.is_file(): z.write(p,p.relative_to(root/'_preview').as_posix())
with zipfile.ZipFile(out/'site-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['website','tools']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts: z.write(p,p.relative_to(root).as_posix())
 for name in ['_config.personal.yml','Gemfile.site','Gemfile.site.lock','LICENSE','docs/PERSONAL-SITE.md','docs/PUBLISHING.md']:
  p=root/name
  if p.exists():z.write(p,name)
print('Prepared release/site.zip and release/site-source.zip')
