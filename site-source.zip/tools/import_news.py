"""Import only News; preserve the manually maintained profile and DOI data."""
from pathlib import Path
from datetime import datetime
import json,re
import openpyxl
ROOT=Path(__file__).resolve().parents[1]
w=openpyxl.load_workbook(ROOT.parent/'学术信息.xlsx',data_only=True)
# English translations keyed to the inspected source rows.
english={
2:('NeurIPS 2026','Sydney, Australia','I plan to visit ISA at the University of Sydney on December 3–4. Our poster, “GCD: GCM-consistent Diffusion for Zero-shot Downscaling across Heterogeneous GCMs,” is scheduled for December 7. I also look forward to discussions at the NeurIPS 2026 Workshop on Tackling Climate Change with Machine Learning.'),
3:('UNEP Digital Day','Nairobi, Kenya','Presented “AI for Sustainable Cities and Climate Resilience” as an AI partner of UNEP.'),
4:('EMNLP 2026','Budapest, Hungary','Poster: “MoralSteer: Safety-Preserving Fidelity Gains in Morally Complex Role-Playing via Theory-Guided On-Policy Self-Distillation.”'),
5:('2026 Exchange Meeting for Young Scientists Fund (Category C) Projects in Macroeconomic Management and Policy','Yangling, China','Presented “Multi-Agent Large Language Models for Causal Evaluation of Energy and Environmental Policies.”'),
6:('International Symposium on Sustainability, Health and Wellbeing: Insights from China and Beyond','Shanghai, China','Presented “AI Empowered Coupling of Climate and Social System” at the symposium hosted by the University of Sydney.'),
7:('University of British Columbia','Vancouver, Canada','Visited the Faculty of Forestry at the University of British Columbia (UBC).'),
8:('FAccT 2026','Montréal, Canada','Attended the 2026 ACM Conference on Fairness, Accountability, and Transparency.'),
9:('Stanford University','San Francisco, USA','Visited faculty at the Stanford Graduate School of Business (GSB).'),
10:('UCSD PES Community Talks','San Diego, USA','Presented “AI for Climate and Social System.”'),
11:('EGU General Assembly 2026','Vienna, Austria','Presented “Generative spatiotemporal downscaling model improves projections of climate extremes,” selected as an EGU Highlight.'),
12:('University of California San Diego','San Diego, USA','Arrived at UC San Diego for a visiting research appointment.'),
13:('University of Sydney','Sydney, Australia','Arrived at the University of Sydney for a visiting research appointment.'),
14:('International Conference on Planetary Actions for Sustainability 2025','Tokyo, Japan','Poster: “Health and economic co-benefits of national climate mitigation policies: a global longitudinal analysis.”'),
15:('11th International Conference on Computational Social Science','Linköping, Sweden','Attended the 11th International Conference on Computational Social Science.'),
16:('AI4UIAQCE Implementation Workshop','Shanghai, China','Presented “Planet Intelligence@Climate.”'),
17:('AI + Water Resources Interdisciplinary Research Meeting · Hohai University','Nanjing, China','Presented “Measuring Economic Risks to Urban Industries from Flooding.”'),
18:('2nd Sydney-Fudan Forum on Sustainability, Big Data, Climate and Health','Suzhou, China','Presented “Bridging Interdisciplinary Understanding of Climate Science through AI and Large Language Model.”'),
19:('Strategic Development Symposium · Shanghai Academy of AI for Science','Shanghai, China','Presented “Applications of LLMs in Climate Change: A Bridge for Interdisciplinary Collaboration and Consensus Building.”'),
20:('Open Forum on Electricity Market Development and Low-Carbon Transition · Shanghai Academy of AI for Science','Shanghai, China','Presented “Green Investment Strategies for Power System Transition: A Heterogeneous-Agent Perspective.”'),
21:('Sydney-Fudan Climate and Health Workshop','Sydney, Australia','Presented “Wealth Inequality Drives Imbalanced Health Benefits from Extreme Temperature Adaptation.”'),
22:('Intelligent Strategies for Energy Transition and Climate Action · National University of Singapore','Singapore','Presented “Inequalities in extreme temperature adaptation will amplify health losses” at the workshop hosted by the Energy Studies Institute.'),
23:('10th International Conference on Computational Social Science','Philadelphia, USA','Poster: “Inferring Bidding and Pricing for Electricity Spot Market: a Novel Multi-Agent Reinforcement Learning Approach.”'),
24:('Nexus Forum 2024 on Sustainable Exploration of Interdisciplinary Research and Innovation','Hong Kong, China','Poster: “Policy Simulation of Power Green Transition in Competitive Market.”'),
25:('28th Annual Conference of the European Association of Environmental and Resource Economists (EAERE)','Limassol, Cyprus','Attended the 28th EAERE Annual Conference.')}
def clean(v):return re.sub(r'\s+',' ',str(v or '')).strip()
def iso(v):return datetime.strptime(v.strip(),'%Y/%m/%d').date().isoformat()
items=[]
for row,cells in enumerate(w['News'].iter_rows(min_row=2),2):
 values=[c.value for c in cells]
 if not any(v is not None for v in values):continue
 raw,event,place,body,note=values[:5]
 if isinstance(raw,datetime):start=end=raw.date().isoformat()
 else:
  parts=str(raw).split('-');start=iso(parts[0]);end=iso(parts[-1])
 if row==12:start=end='2026-02-26' # Explicitly confirmed by user, 2026-11-17.
 en_title,en_place,en_body=english[row]
 zh_body=clean(body)
 zh_body=zh_body.replace('presentation','报告').replace('Poster','海报展示').replace('poster','海报展示')
 if row==3:zh_body='作为 UNEP 的人工智能合作伙伴，作报告《AI for Sustainable Cities and Climate Resilience》。'
 if row==7:zh_body='访问不列颠哥伦比亚大学（UBC）林学院。'
 if row==9:zh_body='访问斯坦福大学商学院（GSB），与学院教师交流。'
 if row==2:zh_body='计划于12月3日至4日到访悉尼大学 ISA；12月7日展示海报《GCD: GCM-consistent Diffusion for Zero-shot Downscaling across Heterogeneous GCMs》。也期待在 NeurIPS 2026 Workshop on Tackling Climate Change with Machine Learning 中与大家交流。'
 if row==12:zh_body='赴加州大学圣地亚哥分校开展访问研究。'
 if row==13:zh_body='赴悉尼大学开展访问研究。'
 item={'id':f'news-{row:02}','start':start,'end':end,'planned':row==2,'title':{'en':en_title,'zh':clean(event)},'location':{'en':en_place,'zh':clean(place)},'body':{'en':en_body,'zh':zh_body},'url':clean(note),'source':f'News!A{row}:E{row}'}
 if row in (18,21):item['title']['zh']=en_title
 if item['url']:assert item['url'].startswith('https://')
 items.append(item)
supplement=ROOT/'website/_data/news_additions.json'
if supplement.exists():
 items.extend(json.loads(supplement.read_text(encoding='utf-8')))
items.sort(key=lambda n:n['start'],reverse=True)
editorial=ROOT/'website/_data/news_editorial.json'
if editorial.exists():
 overrides=json.loads(editorial.read_text(encoding='utf-8'))
 for item in items:
  item.update(overrides.get(item['id'],{}))
out=ROOT/'website/_data/news.json'
out.write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Imported {len(items)} news items; UCSD date corrected with user confirmation.')
