"""Generate bilingual Jekyll pages from website/_data/profile.json."""
from pathlib import Path
import json, html
ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'website/_data/profile.json').read_text(encoding='utf-8'))
NEWS=json.loads((ROOT/'website/_data/news.json').read_text(encoding='utf-8'))
NAV=[('about','About','关于我'),('news','News','动态'),('research','Research','研究'),('publications','Publications','论文'),('projects','Projects','项目'),('service','Service','教学与服务'),('cv','CV','经历')]
def esc(s):return html.escape(str(s),quote=True)
def t(obj,lang):return obj[lang] if isinstance(obj,dict) else obj
def tr(en,zh,lang):return en if lang=='en' else zh
def url(key,lang):return f'/{lang}/'+('' if key=='about' else key+'/')
def link(path):return "{{ '"+path+"' | relative_url }}"
def heading(label,en,zh,desc,lang):return f'<div class="page-heading"><p class="eyebrow">{label}</p><h1>{tr(en,zh,lang)}</h1><p>{desc}</p></div>'
def section(en,zh,body,lang,id='',extra=''):
 return f'<section class="section" id="{id}"><div class="section-heading"><h2>{tr(en,zh,lang)}</h2>{extra}</div>{body}</section>'
def paper(p,lang):
 authors=esc(p['authors'])
 # Only disambiguated names are highlighted. The 2019 citation has two Shi, Z. entries.
 if p['year']!=2019:
  authors=authors.replace('Zhengyu Shi','<strong>Zhengyu Shi</strong>').replace('Shi, Z.','<strong>Shi, Z.</strong>')
 note=[]
 if p['equal']:note.append(tr('Co-first author','共同第一作者',lang))
 if t(p['note'],lang):note.append(t(p['note'],lang))
 urls=''
 if p['doi']: urls+=f'<a href="https://doi.org/{esc(p["doi"])}">DOI ↗</a>'
 if p['url']:urls+=f'<a href="{esc(p["url"])}">{tr("Paper","论文",lang)} ↗</a>'
 return f'''<article class="publication" data-type="{p['type']}" id="{p['id']}"><div class="pub-side"><span class="venue-label">{esc(p['label'])}</span></div><div><h3>{esc(p['title'])}</h3><p class="pub-authors">{authors}</p><p class="pub-meta"><em>{esc(p['venue'])}</em> · {p['year']}</p>{'<p class="pub-note">'+esc(' · '.join(note))+'</p>' if note else ''}{'<div class="pub-links">'+urls+'</div>' if urls else ''}</div></article>'''
def timeline(entries,lang):
 return '<div class="timeline">'+''.join(f'<div class="timeline-entry"><time>{t(e["date"],lang)}</time><div><h3>{t(e["title"],lang)}</h3><p>{t(e["place"],lang)}</p>{"<p>"+t(e["note"],lang)+"</p>" if t(e["note"],lang) else ""}</div></div>' for e in entries)+'</div>'
def contact(lang):
 return f'<div class="contact-block"><p><a href="mailto:{DATA["email"]}">{DATA["email"]}</a><br><a href="mailto:{DATA["email_secondary"]}">{DATA["email_secondary"]}</a></p><address>{t(DATA["address"],lang)}</address><a href="{DATA["scholar"]}">Google Scholar ↗</a></div>'
def about(lang):
 name=t(DATA['name'],lang);secondary=tr('施正昱','Zhengyu Shi',lang)
 s=f'''<section class="hero"><div class="hero-copy"><div class="hero-title"><p class="eyebrow">{tr('Energy · Climate · Intelligence','能源 · 气候 · 智能',lang)}</p><h1>{name}<span>{secondary}</span></h1><p class="role">{t(DATA['role'],lang)}</p><p class="affiliation">{t(DATA['affiliation'],lang)}</p></div><p class="intro">{t(DATA['intro'],lang)}</p><p class="intro">{t(DATA['intro2'],lang)}</p><div class="contact-links"><a href="mailto:{DATA['email']}">{tr('Email','电子邮箱',lang)} ↗</a><a href="{DATA['scholar']}">Google Scholar ↗</a><a href="{link(url('cv',lang))}">{tr('Curriculum vitae','个人履历',lang)} →</a></div><div class="research-topics">{''.join('<span class="topic">'+t(x,lang)+'</span>' for x in DATA['topics'])}</div></div><aside class="hero-aside"><div class="portrait-frame"><img src="{link('/assets/img/portrait.jpg')}" alt="{tr('Portrait of Zhengyu Shi','施正昱个人照片',lang)}" width="720" height="960" fetchpriority="high"></div><div class="portrait-caption"><span>{tr('FUDAN UNIVERSITY','复旦大学',lang)}</span><span>{tr('SHANGHAI, CHINA','中国 · 上海',lang)}</span></div></aside></section>'''
 s+=section('Latest news','最新动态',news_list(NEWS[:5],lang,compact=True),lang,'news',f'<a href="{link(url("news",lang))}">{tr("All news","全部动态",lang)} →</a>')
 s+=section('Academic experience','学术经历','<ul class="service-list">'+''.join('<li>'+t(x,lang)+'</li>' for x in DATA['about_highlights'])+'</ul>',lang,'experience')
 teasers=''.join(f'<article class="research-teaser"><span class="number">0{i+1}</span><h3>{t(r["title"],lang)}</h3><p>{t(r["short"],lang)}</p><a href="{link(url("research",lang))}#{r["id"]}">{tr("Explore research","了解研究",lang)} →</a></article>' for i,r in enumerate(DATA['research']))
 s+=section('Research interests','研究方向','<div class="research-overview">'+teasers+'</div>',lang,'interests')
 s+=section('Research in practice','成果应用','<p>'+t(DATA['applications'],lang)+'</p>',lang,'applications')
 s+=section('Selected publications','代表论文',''.join(paper(p,lang) for p in DATA['papers'] if p['selected']),lang,'selected',f'<a href="{link(url("publications",lang))}">{tr("All publications","全部论文",lang)} →</a>')
 compact=''.join(f'<div class="compact-entry"><small>{p["period"]}</small><h3>{t(p["funder"],lang)}</h3><p>{t(p["role"],lang)}</p></div>' for p in DATA['projects'] if p['kind']=='led')
 compact+=f'<div class="compact-entry"><small>2025–2026</small><h3>{tr("Shanghai Super Postdoctoral Fellow Program","上海市“超级博士后”",lang)}</h3></div>'
 s+='<div class="home-bottom">'+section('Research support','科研支持',compact,lang,'support')+section('Get in touch','联系我',contact(lang),lang,'contact')+'</div>'
 return s
def research(lang):
 s=heading('RESEARCH','Research','研究',tr('Studying energy transitions and climate resilience through statistical learning and computational models.','以统计学习与计算模型研究能源转型与气候韧性。',lang),lang)
 for i,r in enumerate(DATA['research']):
  extra=''
  if r['id']=='climate':
   m=DATA['climate_model']
   extra=f'<div class="feature-research"><p class="eyebrow">{tr("Research spotlight","重点研究",lang)}</p><h3>{m["title"]}</h3><p class="detail-tags">{t(m["subtitle"],lang)}</p><p>{t(m["text"],lang)}</p><p>{t(m["impact"],lang)}</p></div>'
  s+=f'<section class="research-detail" id="{r["id"]}"><span class="index">0{i+1}</span><div><h2>{t(r["title"],lang)}</h2><p>{t(r["text"],lang)}</p><p class="detail-tags">{t(r["topics"],lang)}</p>{extra}</div></section>'
 s+=section('From research to practice','研究与实践',f'<p>{tr("Research on flood exposure and losses was integrated into China Pacific Property Insurance’s Risk Radar platform in 2025, supporting more than 30 insurance projects according to the project record.","洪水暴露与损失相关研究成果于2025年接入中国太平洋财产保险“风险雷达”平台，目前已支撑30余个投保项目。",lang)}</p>',lang,'impact')
 s+='<p>'+t(DATA['applications'],lang)+'</p>'
 return s
def publications(lang):
 s=heading('PUBLICATIONS','Publications','论文',tr('Journal articles, conference papers, and conference abstracts. Co-first authorship is indicated where applicable.','期刊论文、会议论文与会议摘要；共同第一作者身份在对应条目中标注。',lang),lang)
 options=[('all','All','全部'),('journal','Journals','期刊论文'),('conference','Conferences','会议论文'),('abstract','Abstracts & talks','会议摘要')]
 s+='<div class="filter-bar"><div class="filters" role="group" aria-label="'+tr('Publication type','成果类型',lang)+'">'+''.join(f'<button data-filter="{key}" aria-pressed="{str(key=="all").lower()}">{tr(en,zh,lang)}</button>' for key,en,zh in options)+'</div><label class="search-wrap"><span class="sr-only">'+tr('Search publications','搜索论文',lang)+'</span><input type="search" id="publication-search" placeholder="'+tr('Search title, author, venue…','搜索标题、作者、期刊…',lang)+'"></label></div>'
 s+='<p id="result-count" class="result-count" aria-live="polite">'+tr('11 results','11 项成果',lang)+'</p>'
 for year in sorted({p['year'] for p in DATA['papers']},reverse=True):
  s+=f'<section class="publication-year-group"><h2>{year}</h2><div>'+''.join(paper(p,lang) for p in DATA['papers'] if p['year']==year)+'</div></section>'
 s+='<p id="no-results" hidden>'+tr('No publications match your search. Try another keyword or category.','没有匹配的论文，请尝试其他关键词或分类。',lang)+'</p>'
 return s
def projects(lang):
 s=heading('PROJECTS & SUPPORT','Projects & support','科研项目与支持',tr('Research funding, collaborative projects, and talent support.','主持与参与的科研项目，以及人才支持计划。',lang),lang)
 for kind,en,zh in [('led','Principal investigator','主持项目'),('collaborative','Collaborative projects','参与项目')]:
  body=''.join(f'<article class="project-row"><time>{p["period"]}</time><div><h3>{t(p["title"],lang)}</h3><p>{t(p["funder"],lang)}</p><p class="project-role">{t(p["role"],lang)}</p></div></article>' for p in DATA['projects'] if p['kind']==kind)
  s+=section(en,zh,body,lang,kind)
 s+=section('Talent support','人才支持',f'<p>{t(DATA["support"],lang)}</p>',lang,'talent')
 return s
def service(lang):
 s=heading('TEACHING & SERVICE','Teaching & service','教学与学术服务',tr('Teaching, scientific assessments, editorial work, and service to the research community.','课程教学、科学评估报告、编委工作与学术共同体服务。',lang),lang)
 for key,en,zh in [('teaching','Teaching & mentoring','教学与指导'),('service','Scientific & editorial service','科学评估与编委工作')]:
  s+=section(en,zh,'<ul class="service-list">'+''.join('<li>'+t(item,lang)+'</li>' for item in DATA[key])+'</ul>',lang,key)
 s+=section('Journal reviewing','期刊审稿','<ul class="service-list">'+''.join('<li>'+x+'</li>' for x in DATA['reviewing'])+'</ul>',lang,'reviewing')
 return s
def cv(lang):
 s=heading('CURRICULUM VITAE','Curriculum vitae','个人经历',tr('Academic appointments, education, and international exchange.','任职、教育背景与国际交流。',lang),lang)
 for key,en,zh in [('appointments','Appointments','工作经历'),('education','Education','教育背景'),('visits','Visiting appointments','访问经历')]:
  s+=section(en,zh,timeline(DATA[key],lang),lang,key)
 s+=section('Invited talks','受邀报告','<p>'+t(DATA['talks'],lang)+'</p>',lang,'talks')
 s+=section('Contact','联系信息',contact(lang),lang,'contact')
 return s
def news_list(items,lang,compact=False):
 result='<div class="news-list'+(' is-compact' if compact else '')+'">'
 for n in items:
  dates=n['start'] if n['start']==n['end'] else n['start']+' – '+n['end']
  title=esc(t(n['title'],lang))
  if compact:title=f'<a href="{link(url("news",lang))}#{n["id"]}">{title}</a>'
  badge=f'<span class="news-status">{tr("Planned","计划行程",lang)}</span>' if n['planned'] else ''
  external=f'<a class="news-external" href="{esc(n["url"])}">{esc(t(n["link_label"],lang)) if n.get("link_label") else tr("Event / paper","活动 / 论文链接",lang)} ↗</a>' if n['url'] else ''
  photo=''
  photos=([{'image':n['image'],'caption':n['caption'],'portrait':n.get('portrait',False)}] if n.get('image') else [])+n.get('extra_images',[])
  for attachment in (photos[:1] if compact else photos):
   src=link(attachment['image'])
   destination=link(url('news',lang))+'#'+n['id'] if compact else src
   caption=esc(t(attachment['caption'],lang))
   photo_class='news-photo is-portrait' if attachment.get('portrait') else 'news-photo'
   photo+=f'<figure class="{photo_class}"><a href="{destination}" aria-label="{caption}"><img src="{src}" alt="{caption}" loading="lazy" decoding="async"></a><figcaption>{caption}</figcaption></figure>'
  if len(photos)>1 and not compact:
   photo='<div class="news-gallery">'+photo+'</div>'
  body_html="".join('<p class="news-body">'+esc(paragraph)+"</p>" for paragraph in t(n["body"],lang).split("\n\n"))
  result+=f'<article class="news-entry" id="{n["id"]}"><div class="news-date"><time datetime="{n["start"]}">{dates}</time>{badge}</div><div><h3>{title}</h3><p class="news-location">{esc(t(n["location"],lang))}</p>{body_html}{external}{photo}</div></article>'
 return result+'</div>'
def news(lang):
 s=heading('NEWS','News & updates','学术动态',tr('Conferences, talks, research visits, and upcoming plans.','会议、报告、学术访问与近期计划。',lang),lang)
 for year in sorted({n['start'][:4] for n in NEWS},reverse=True):
  s+=section(year,year,news_list([n for n in NEWS if n['start'].startswith(year)],lang),lang,'year-'+year)
 return s
RENDER={'about':about,'news':news,'research':research,'publications':publications,'projects':projects,'service':service,'cv':cv}
for lang in ['en','zh']:
 for key,en,zh in NAV:
  meta={'layout':'personal','title':tr(en,zh,lang),'lang':'en' if lang=='en' else 'zh-CN','key':key,'permalink':url(key,lang),'home_url':url('about',lang),'alternate':url(key,'zh' if lang=='en' else 'en'),'en_url':url(key,'en'),'zh_url':url(key,'zh'),'description':tr('Zhengyu Shi, Fudan University. Energy governance, agent-based modeling, and statistical machine learning.','施正昱，复旦大学博士后。研究方向：能源治理、智能体建模、统计机器学习。',lang),'navigation':[{'key':k,'label':tr(e,z,lang),'url':url(k,lang)} for k,e,z in NAV]}
  dest=ROOT/'website'/lang/(key+'.html');dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_text('---\n'+json.dumps(meta,ensure_ascii=False,indent=2)+'\n---\n'+RENDER[key](lang),encoding='utf-8')
(ROOT/'website/index.html').write_text('---\nlayout: null\n---\n<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0; url={{ \'/en/\' | relative_url }}"><title>Zhengyu Shi · 施正昱</title></head><body><p><a href="{{ \'/en/\' | relative_url }}">English</a> · <a href="{{ \'/zh/\' | relative_url }}">中文</a></p></body></html>',encoding='utf-8')
print(f'Generated {len(NAV)*2} bilingual content pages and the English entry point.')


