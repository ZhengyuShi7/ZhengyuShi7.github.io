"""Package the already-rendered preview with file://-compatible links."""
from pathlib import Path
import os, re, shutil
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'_preview'; dest=ROOT/'_offline'
shutil.copytree(src,dest,dirs_exist_ok=True)
for p in dest.rglob('*.html'):
 text=p.read_text(encoding='utf-8')
 def relative(m):
  attribute,path=m.group(1),m.group(2)
  parts=path.split('#',1); target=dest/parts[0].lstrip('/')
  if parts[0].endswith('/'):target=target/'index.html'
  rel=os.path.relpath(target,p.parent).replace('\\','/')
  if len(parts)>1:rel+='#'+parts[1]
  return attribute+'="'+rel+'"'
 text=re.sub(r'(href|src)="(/[^"\s]*)"',relative,text)
 text=re.sub(r'url=/en/', 'url=en/index.html',text)
 p.write_text(text,encoding='utf-8')
print('Offline pages packaged.')
